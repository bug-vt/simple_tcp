Starter code for CS4254/5565 Project 3.

This contains two separate environments -- one Docker based intended for both x86 and M1 OSX host systems, the other Virtualbox based for x86 Windows systems. If you're a Linux user, either one will work -- we'd recommend using the VM. To launch your environment, `cd` into the appropriate subdirectory to launch your environment according to the directions in each folder's README.md.
